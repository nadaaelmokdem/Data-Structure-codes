#include "Deque.h"
int Deque::peekfront()
{
 return items[front] ;
}
int Deque::peekrear()
{
return items[rear] ;
}
Deque::Deque()
{
	rear = -1;
	front = -1;
}
int Deque::is_empty()
{
	if (rear == -1 && front == -1)
		return 1;
	return 0;
}
int Deque::is_full()
{
	if ((front == -1 && rear == size - 1) || (front == rear + 1))
		return 1;
	return 0;
}
void Deque::insertfront(int data)
{
	if (is_full())
		cout << "Queue is full " << endl;
	if (rear == -1 && front == -1)
	{
		rear = 0;
		front = 0;
	}
	else if (front == 0)
	{
		front = size-1;
	}
	else
	{
		front--;
		items[front] = data;
	}
}
void Deque::insertrear(int data)
{
	if (is_full())
		cout << "Queue is full";
	if (rear == -1 && front == -1)
	{
		rear = 0;
		front = 0;
	}
	else if (rear == size - 1)
	{
		rear = 0;
	}
	else
	{
		rear++;
		items[rear] = data;
	}
}
int Deque::removefront()
{
	if (is_empty())
	{
		cout << "Queue is empty" << endl;
		return 0;
	}
	int temp = items[front];
	if (front == rear)
	{
		rear = 0;
		front = 0;
	}
	else if (front == size - 1)
	{
		front = 0;
	}
	else
	{
		front++;
	}
	return temp;
}
int Deque::removerear()
{
	if (is_empty())
	{
		cout << "Queue is empty";
		return 0;
	}
	int temp = items[rear];
	if (rear = front)
	{
		rear = -1;
		front = -1;
	}
	else if (rear == 0)
	{
		rear = size - 1;
	}
	else
	{
		rear--;
	}
	return temp;
}
void Deque::display()
{
	int frontp = front, rearp = rear;
	if (front == -1)
	{
		while (frontp <= rearp)
		{
			cout << items[frontp] << endl;
			frontp++;
		}
	}
	else
	{
		while (frontp == size-1)
		{
			cout << items[frontp] << endl;
			frontp++;
		}
		while (frontp <= rearp)
		{
			cout << items[frontp];
			frontp++;
		}
	}
}