#pragma once
#include <iostream>
using namespace std;
#define size 50
class Deque
{
private:
	int items[size];
	int rear;
	int front;
public:
	Deque();
	int is_empty();
	int is_full();
	void insertfront(int data);
	void insertrear(int data);
	int removefront();
	int removerear();
	void display();
	int peekfront();
	int peekrear();
};

