#include "Deque.h"
using namespace std;
int main()
{
	Deque d;
	int choice, data;
	while (1) {
		cout << "1-Insert at Rear" << endl;
		cout << "2 - Remve from Front" << endl;
		cout << "3 - Remove from Rear" << endl;
		cout << "4 - Display" << endl;
		cout << "5 - Quit" << endl;
		cout << "\nEnter your choice: ";
		cin >> choice;
		switch (choice)
		{
		case 1:
			cout << "Enter data to be inserted" << endl;
			cin >> data;
			d.insertrear(data);
			break;
		case 2:
			d.removefront();
			break;
		case 3:
			d.removerear();
			break;
		case 4:
			d.display();
			break;
		case 5:
			break;
		}
	}
}