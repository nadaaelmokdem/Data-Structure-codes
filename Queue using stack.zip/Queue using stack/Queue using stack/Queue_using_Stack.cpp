#include <stack>

#include "Queue_using_Stack.h"

int Queue_using_Stack::is_empty() {
    return stack.empty();
}

bool Queue_using_Stack::is_full() {
    return false;
}

void Queue_using_Stack::enqueue(int item) {
    if (is_full()) {
        cout << "Queue overflow (shouldn't happen!)"; // Informational message
        return;
    }
    stack.push(item);
}

int Queue_using_Stack::dequeue() {
    if (is_empty()) {
        cout << "Queue is underflow";
        return -1;
    }
    int item = stack.top();
    stack.pop();
    return item;
}

void Queue_using_Stack::display() {
    if (is_empty()) {
        cout << "Queue is underflow";
        return;
    }
    std::stack<int> temp = stack;
    while (!temp.empty()) {
        cout << temp.top() << " ";
        temp.pop();
    }
    cout << endl;
}
