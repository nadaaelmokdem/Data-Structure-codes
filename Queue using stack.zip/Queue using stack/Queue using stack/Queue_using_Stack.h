#pragma once
#include <iostream>
#include <Stack>
#include <string>
using namespace std;
class Queue_using_Stack
{
private:
public:
	stack <int> stack;
	int main, sec;
	int is_empty();
	bool is_full();
	void enqueue(int item);
	int dequeue();
	void display();

};

