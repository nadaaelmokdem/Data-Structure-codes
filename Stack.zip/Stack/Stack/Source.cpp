#include "stack.h"
int main()
{
	stack s;
	int num,num2, exit= 1;
	do 
	{
		cout << "Enter number of operation " << endl;
		cin >> num;
		switch (num)
		{
		case 1:
			cout << "Enter the number you want to push" << endl;
			cin >> num2;
			s.push(num2);
			break;
		case 2:
			s.pop();
			break;
		case 3:
			s.display();
			break;
		default:
			exit = 0;
			break;
		}
	} while (exit != 4);
}