#include "stack.h"
stack::stack()
{
	top = -1;
}
int stack::is_empty()
{
	if (top == -1)
		return 1;
	return 0;
}
int stack::is_full()
{
	if (top == size - 1)
		return 1;
	return 0;
}
void stack::push(int x)
{
	if (is_full())
	{
		cout << "stack is overflow " << endl;
	}
	else
	{
		arr[top++] = x;
	}
}
int stack::pop()
{
	if (is_empty())
	{
		cout << "stack is underflow " << endl;
		return 0;
	}
	else
	{
		int item = arr[top];
		top--;
		return item;
	}
}
void stack::display()
{
	for (int i = 0; i < top - 1; i++)
		cout << arr[i] << endl;
}