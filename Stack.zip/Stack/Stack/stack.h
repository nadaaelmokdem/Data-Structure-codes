#pragma once
#include <iostream>
#define  size 10
using namespace std;
class stack
{
private:
	int arr[size];
	int top;
public:
	stack();
	int is_empty();
	int is_full();
	void push(int x);
	int pop();
	void display();
};

