#include <iostream>
using namespace std;
struct person
{
	char name[50];
	int age;
	float salary;
};
int main()
{
	person p;
	cout << "Enter Your Name\n";
	cin.get(p.name, 50);
	cout << "Enter Your Age";
	cin >> p.age;
	cout << "Enter Your Salary ";
	cin >> p.salary;

	cout << "Your Name is " << p.name << endl;
	cout << "Your age is " << p.age << endl;
	cout << "Your salary is " << p.salary << endl;


}