#include "dstack.h"
#include <iostream>
using namespace std;
/////////////////////////////////////////////////////////////////////////
void main()
{
	dstack s;
	s.push(5);
	s.push(3);
	s.display();
	s.pop();
	s.display();
	system("pause");
}