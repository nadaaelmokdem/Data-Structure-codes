#include "dstack.h"

dstack::dstack(int stackSize) {
    top = -1;
    size = stackSize; 
    arr = new int(size);
}

dstack::~dstack() {
    delete[] arr;
}

int dstack::is_empty() {
    return top == -1;
}

int dstack::is_full() {
    return top == size - 1; 
}

void dstack::push(int x) {
    if (is_full()) {
        cout << "Stack overflow\n";
        return;
    }
    top++;
    arr[top] = x;
}

int dstack::pop() {
    if (is_empty()) {
        cout << "Stack underflow\n";
        return -1;
    }
    int item = arr[top];
    top--;
    return item;
}

void dstack::display() {
    for (int i = 0; i < top; i++) { 
        cout << arr[i] << " ";
    }
    cout << endl;
}
