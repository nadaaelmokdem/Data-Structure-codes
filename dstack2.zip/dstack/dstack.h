#pragma once
#include <iostream>
using namespace std;
class dstack {
private:
    int top;
    int size; 
    int* arr;

public:
    dstack(int stackSize); 
    ~dstack();            
    int is_empty();
    int is_full();
    void push(int x);
    int pop();
    void display();
};