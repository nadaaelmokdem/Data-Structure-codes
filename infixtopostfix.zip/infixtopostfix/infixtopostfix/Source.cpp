#include <iostream>
#include <string>
#include <stack>

using namespace std;

int precedence(char c) {
    if (c == '^')
        return 3;
    if (c == '*' || c == '/' || c == '%')
        return 2;
    if (c == '+' || c == '-')
        return 1;
    else
        return -1;
}

void postfix(string s) {
    stack<char> st;
    string result;

    for (int i = 0; i < s.length(); i++) {
        char c = s[i];
        if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9')) {
            result += static_cast<int>(c); // Convert to ASCII and append to result
        }
        else if (c == '(') {
            st.push('(');
        }
        else if (c == ')') {
            while (!st.empty() && st.top() != '(') {
                char temp = st.top();
                st.pop();
                result += temp;
            }
            st.pop(); // Discard the opening parenthesis
        }
        else {
            while (!st.empty() && precedence(c) <= precedence(st.top())) {
                char temp = st.top();
                st.pop();
                result += temp;
            }
            st.push(c);
        }
    }

    while (!st.empty()) {
        char temp = st.top();
        st.pop();
        result += temp;
    }

    cout << "Postfix expression: " << result << endl;
}

int main() {
    string exp = "a+b*c/(e-f)";
    postfix(exp);
    return 0;
}
