#include <iostream>
using namespace std;
int main()
{
	int n;
	cout << "Enter number of items ";
	cin >> n;
	int* num = new int(n);
	cout << "Enter numbers";
	for (int i = 0; i < n; i++)
	{		
		cin >> num[i];
    }
	cout << "You entered";
	for (int i = 0; i < n; i++)
	{
		cout << num[i] << endl;
	}
	delete[] num;
	return 0;
}
